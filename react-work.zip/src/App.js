import Nav from "./components/Nav/Nav";
import Footer from "./components/Footer/Footer";
import Search from "./components/resSearch/resSearch.jsx";
import Home from "./components/Home";
import Product from './components/Products/Product';
import Contact from './components/Contact/Contact';
import Shop from './components/Shop/Shop.jsx';
import Cart from "./components/Cart/Cart";
import Grid from './components/Shop/Grid.jsx';

import {
  BrowserRouter as Router,
  Routes,
  Route
} from "react-router-dom";

import './components/HomePage/Styles/MainStyles.css'
function App() {
  return (
    <>
      <Router>
        <Nav />

        <Routes>
          <Route path="/" element={<Home />}/>
          <Route path="/Products/:id" element={<Product />}/>
          <Route path="/Shop" element={<Shop />}/>
          <Route path="/Grid" element={<Grid />}/>
          <Route path="/Contact" element={<Contact />}/>
          <Route path="/Cart" element={<Cart />}/>
          <Route path="/Search" element={<Search />}/>
          <Route path="*" element={<Home />}/>
        </Routes>
        
        <Footer />
     </Router>
    </>
  );
}

export default App;