import "../Styles/HomeCategories.css";
import { RiShirtLine } from "react-icons/ri";

function HomeCategories() {
  return (
    <>
      <div className="home-categories w-100">
        <div className="home-categories_title fw-bold">
          <span>Category</span> <span className="main-text">  More Category</span>
        </div>

        <div className="home-categories_items w-100">
          <div className="home-categories_item">
            <RiShirtLine />
            Man Shirt
          </div>




          <div className="home-categories_item">
            <RiShirtLine />
            Man Shirt
          </div>




          <div className="home-categories_item">
            <RiShirtLine />
            Man Shirt
          </div>





          <div className="home-categories_item">
            <RiShirtLine />
            Man Shirt
          </div>
        </div>
      </div>
    </>
  );
}

export default HomeCategories;
