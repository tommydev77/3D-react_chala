import "../Styles/HomeProduct.css";
import { AiOutlineStar } from "react-icons/ai";

function HomeProduct() {
  return (
    <>
      <div className="home-product">
        <div className="row">
          <div className="col-md-6">
            <div className="row">
              <div className="col-6">
                <div className="home-product_item">
                  <img src={require("../images/homeproduct.png")} alt="" />

                  <div>
                    <div className="home-product_item_title">
                      Nike Air Max 270 React
                    </div>

                    <div className="home-product_item_stars">
                      <AiOutlineStar />
                      <AiOutlineStar />
                      <AiOutlineStar />
                      <AiOutlineStar />
                      <AiOutlineStar />
                    </div>

                    <div className="home-product_item_price">
                      <span className="main-text">$299,43</span>
                      <del>
                        <span className="grey-text text-underline">
                          $534,33
                        </span>
                      </del>
                      <span className="second-text"> 24% off</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="col-6">
                <div className="home-product_item">
                  <img src={require("../images/homeproduct.png")} alt="" />

                  <div>
                    <div className="home-product_item_title">
                      Nike Air Max 270 React
                    </div>

                    <div className="home-product_item_stars">
                      <AiOutlineStar />
                      <AiOutlineStar />
                      <AiOutlineStar />
                      <AiOutlineStar />
                      <AiOutlineStar />
                    </div>

                    <div className="home-product_item_price">
                      <span className="main-text">$299,43</span>
                      <del>
                        <span className="grey-text text-underline">
                          $534,33
                        </span>
                      </del>
                      <span className="second-text"> 24% off</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="col-md-6">
            <div className="row">
              <div className="col-6">
                <div className="home-product_item">
                  <img src={require("../images/homeproduct.png")} alt="" />

                  <div>
                    <div className="home-product_item_title">
                      Nike Air Max 270 React
                    </div>

                    <div className="home-product_item_stars">
                      <AiOutlineStar />
                      <AiOutlineStar />
                      <AiOutlineStar />
                      <AiOutlineStar />
                      <AiOutlineStar />
                    </div>

                    <div className="home-product_item_price">
                      <span className="main-text">$299,43</span>
                      <del>
                        <span className="grey-text text-underline">
                          $534,33
                        </span>
                      </del>
                      <span className="second-text"> 24% off</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="col-6">
                <div className="home-product_item">
                  <img src={require("../images/homeproduct.png")} alt="" />

                  <div>
                    <div className="home-product_item_title">
                      Nike Air Max 270 React
                    </div>

                    <div className="home-product_item_stars">
                      <AiOutlineStar />
                      <AiOutlineStar />
                      <AiOutlineStar />
                      <AiOutlineStar />
                      <AiOutlineStar />
                    </div>

                    <div className="home-product_item_price">
                      <span className="main-text">$299,43</span>
                      <del>
                        <span className="grey-text text-underline">
                          $534,33
                        </span>
                      </del>
                      <span className="second-text"> 24% off</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default HomeProduct;
