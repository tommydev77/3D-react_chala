import Bunner from "../noResponseComponents/Bunner/Bunner";
import WhyUs from "../noResponseComponents/WhyUs/WhyUs";
import HomeNews from "../noResponseComponents/News/News";
import FeaturedProducts from '../noResponseComponents/FeaturedProducts/FeaturedProducts';
import SearchInput from '../noResponseComponents/SearchInput/SearchInput';
import './NoResponse.css'
function NoResponse() {
  return (
    <>
      <div className="noresponse">
        <Bunner />
        <WhyUs />
        <HomeNews />
        <FeaturedProducts />
        <SearchInput />
      </div>
    </>
  );
}

export default NoResponse;
