import "../Styles/LoadMore.css";
import { Link } from "react-router-dom";

function LoadMore() {
  return (
    <>
      <div className="loadmorelink text-uppercase">
        <Link to="/Grid">
          Load More
        </Link>
      </div>
    </>
  );
}

export default LoadMore;
