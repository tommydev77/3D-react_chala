import './Main.css'

function Main() {
    return (  
        <>
            <main>
                <div className="container"> 
                    <h1> 
                        Super Flash Sale <br /> 50% Off
                    </h1>
                </div>              
            </main>
        </>
    );
}

export default Main;