import '../Styles/RecomendedProduct.css'

function RecomendedProduct() {
  return (
    <>
      <div className="recomended-product">
        <div className="recomended-product_items">
          <div className="recomended-product_items_top">Recomended Product</div>
          <div className="recomended-product_items_bottom">We recommend the best for you</div>
        </div>
      </div>
    </>
  );
}

export default RecomendedProduct;
