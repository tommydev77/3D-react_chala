import "../Styles/FirstCardsStyles.css";

function FirstCards() {
  return (
    <>
      <div className="first-cards container">
        <div className="row my-5 w-100">
          <div className="col-sm-4">
            <div className="first-card my-3">
              <p className="first-card_title">
                FS - QUILTED MAXI <br /> CROSS BAG
              </p>

              <img src={require("../images/first-card-image1.png")} alt="Image" />

              <p className="first-card_description">
                <del>
                  <span className="grey-text text-underline">$534,33</span>
                </del>
                <span className="second-text"> 24% off</span>
              </p>

              <p className="first-card_price main-text">
                <span className="totop">$2</span>99,43
              </p>
            </div>
          </div>

          <div className="col-md-4">
            <div className="first-card my-3">
              <p className="first-card_title">
                FS - QUILTED MAXI <br /> CROSS BAG
              </p>

              <img src={require("../images/first-card-image1.png")} alt="" />

              <p className="first-card_description">
                <del>
                  <span className="grey-text text-underline">$534,33</span>
                </del>
                <span className="second-text"> 24% off</span>
              </p>

              <p className="first-card_price main-text">
               
                <span className="totop">$2</span>99,43
              </p>
            </div>
          </div>

          <div className="col-md-4">
            <div className="first-card my-3">
              <p className="first-card_title">
                FS - QUILTED MAXI <br /> CROSS BAG
              </p>

              <img src={require("../images/first-card-image1.png")} alt="" />

              <p className="first-card_description">
                <del>
                  <span className="grey-text text-underline">$534,33</span>
                </del>
                <span className="second-text"> 24% off</span>
              </p>

              <p className="first-card_price main-text">
             
                <span className="totop">$2</span>99,43
              </p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default FirstCards;
