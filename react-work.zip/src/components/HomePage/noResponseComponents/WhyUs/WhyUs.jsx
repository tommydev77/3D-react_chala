import './WhyUs.css';
import {MdOutlineSupportAgent} from 'react-icons/md'

function WhyUs() {
    return (  
        <>
            <div className="why-us">
                <div className="container">
                    <div className="why-us_items">
                        <div className="why-us_item">
                            <div className="why-us_item_icon">
                                <MdOutlineSupportAgent />
                            </div>


                            <div className="why-us_item_title">
                                SUPPORT 24/7
                            </div>


                            <div className="why-us_item_description">
                            Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                            </div>
                        </div>











                        <div className="why-us_item">
                            <div className="why-us_item_icon">
                                <MdOutlineSupportAgent />
                            </div>


                            <div className="why-us_item_title">
                                SUPPORT 24/7
                            </div>


                            <div className="why-us_item_description">
                            Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                            </div>
                        </div>














                        <div className="why-us_item">
                            <div className="why-us_item_icon">
                                <MdOutlineSupportAgent />
                            </div>


                            <div className="why-us_item_title">
                                SUPPORT 24/7
                            </div>


                            <div className="why-us_item_description">
                            Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}

export default WhyUs;