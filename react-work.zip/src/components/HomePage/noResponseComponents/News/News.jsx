import "./News.css";

function HomeNews() {
  return (
    <>
      <div className="home-news py-5">
        <div className="home-news_title my-5 text-center">LATEST NEWS</div>

        <div className="home-news_cards">
          <div className="home-news_card">
            <div className="row">
              <div className="col-6">
                <img src={require("../../images/newsfigma.png")} alt="" />
              </div>

              <div className="col-6">
                <div className="news_card_date grey-text">01 Jan, 2022</div>

                <div className="news_card_title">Best Design Tools</div>

                <div className="news_card_description">
                  Lorem Ipsum is simply dummy text of the printing and
                  typesetting industry.
                </div>
              </div>
            </div>
          </div>

          <div className="home-news_card">
            <div className="row">
              <div className="col-6">
                <img src={require("../../images/newsfigma.png")} alt="" />
              </div>

              <div className="col-6">
                <div className="news_card_date grey-text">01 Jan, 2022</div>

                <div className="news_card_title">Best Design Tools</div>

                <div className="news_card_description">
                  Lorem Ipsum is simply dummy text of the printing and
                  typesetting industry.
                </div>
              </div>
            </div>
          </div>

          <div className="home-news_card">
            <div className="row">
              <div className="col-6">
                <img src={require("../../images/newsfigma.png")} alt="" />
              </div>

              <div className="col-6">
                <div className="news_card_date grey-text">01 Jan, 2022</div>

                <div className="news_card_title">Best Design Tools</div>

                <div className="news_card_description">
                  Lorem Ipsum is simply dummy text of the printing and
                  typesetting industry.
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default HomeNews;
