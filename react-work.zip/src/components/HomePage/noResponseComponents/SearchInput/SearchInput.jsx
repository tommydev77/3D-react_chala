import './SearchInput.css'

function SearchInputNotRes() {
    return (  
        <>
            <div className="SearchInputNotRes">
                <div className="SearchInputNotRes_items">
                    <input type="text" placeholder="Search query..." />
                    <button>Search</button>
                </div>
            </div>
        </>
    );
}

export default SearchInputNotRes;