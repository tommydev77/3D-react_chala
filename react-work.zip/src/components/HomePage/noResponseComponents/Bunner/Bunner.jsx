import "./Bunner.css";

function Bunner() {
  return (
    <>
      <div className="bunner">
        <div className="row">
          <div className="col-md-6">
            <div className="bunner_top">
              Adidas Men Running <br /> Sneakers
            </div>

            <div className="bunner_bottom">
              <p>Performance and design. Taken right to the edge.</p>

              <button className="text-uppercase">show now</button>
            </div>
          </div>

          <div className="col-md-6">
            <img
              src={require("../../images/bunner.png")}
              className="bunner-image"
              alt="Bunner_Image_3D_Commerce"
            />
          </div>
        </div>
      </div>
    </>
  );
}

export default Bunner;
