import "./FeaturedProducts.css";
import { AiOutlineStar } from "react-icons/ai";

function FeaturedProducts() {
  return (
    <>
      <div className="FeaturedProducts py-5">
        <div className="FeaturedProducts_title my-5 text-center">
          Featured Products
        </div>

        <div className="FeaturedProducts_cards">
          <div className="FeaturedProducts_card">
            <div className="row">
              <div className="col-6">
                <img src={require("../../images/FeturedProduct.png")} alt="" />
              </div>

              <div className="col-6">
                <div className="FeaturedProducts_card_title">
                  Blue Swade Nike Sneakers
                </div>

                <div className="FeaturedProducts_card_stars">
                  <AiOutlineStar />
                  <AiOutlineStar />
                  <AiOutlineStar />
                  <AiOutlineStar />
                  <AiOutlineStar />
                </div>

                <div className="FeaturedProducts_card_price">
                  <span className="second-text">$499 </span>
                  <span className="grey-text">
                    {" "}
                    <del> $599 </del>{" "}
                  </span>
                </div>
              </div>
            </div>
          </div>

          <div className="FeaturedProducts_card">
            <div className="row">
              <div className="col-6">
                <img src={require("../../images/FeturedProduct.png")} alt="" />
              </div>

              <div className="col-6">
                <div className="FeaturedProducts_card_title">
                  Blue Swade Nike Sneakers
                </div>

                <div className="FeaturedProducts_card_stars">
                  <AiOutlineStar />
                  <AiOutlineStar />
                  <AiOutlineStar />
                  <AiOutlineStar />
                  <AiOutlineStar />
                </div>

                <div className="FeaturedProducts_card_price">
                  <span className="second-text">$499 </span>
                  <span className="grey-text">
                    {" "}
                    <del> $599 </del>{" "}
                  </span>
                </div>
              </div>
            </div>
          </div>

          <div className="FeaturedProducts_card">
            <div className="row">
              <div className="col-6">
                <img src={require("../../images/FeturedProduct.png")} alt="" />
              </div>

              <div className="col-6">
                <div className="FeaturedProducts_card_title">
                  Blue Swade Nike Sneakers
                </div>

                <div className="FeaturedProducts_card_stars">
                  <AiOutlineStar />
                  <AiOutlineStar />
                  <AiOutlineStar />
                  <AiOutlineStar />
                  <AiOutlineStar />
                </div>

                <div className="FeaturedProducts_card_price">
                  <span className="second-text">$499 </span>
                  <span className="grey-text">
                    {" "}
                    <del> $599 </del>{" "}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default FeaturedProducts;
