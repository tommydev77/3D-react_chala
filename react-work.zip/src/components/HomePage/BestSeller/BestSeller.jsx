import "../Styles/BestSeller.css";

function BestSeller() {
  return (
    <>
      <div className="best-seller my-3">
        <div className="best-seller_title">BEST SELLER</div>

        <div className="best-seller_links">
          <span className="active">All</span>

          <span>Bags</span>

          <span>Sneakers</span>

          <span>Belt</span>

          <span>Sunglasses</span>
        </div>
      </div>
    </>
  );
}

export default BestSeller;
