import "./Footer.css";

function Footer() {
  return (
    <>
      <footer>
        <div className="container">
          <div className="footer_top">
            <div className="footer_top_item">
              <div>E-Comm</div>
              Lorem Ipsum is simply dummy text of the printing and typesetting
              industry. Lorem Ipsum has been the industry's standard dummy text
              ever.Since the 1500s, when an unknown printer.
            </div>

            <div className="footer_top_item">
              <div>Follow Us</div>
              Since the 1500s, when an unknown printer took a galley of type and
              scrambled.
            </div>

            <div className="footer_top_item">
              <div>Contact Us</div>
              E-Comm , 4578 Marmora Road, Glasgow D04 89GR
            </div>
          </div>

          <div className="footer_bottom">
            <div className="footer_bottom_item">
              <div>Infomation</div> <br />
              About Us Infomation Privacy Policy Terms & Conditions
            </div>

            <div className="footer_bottom_item">
              <div>Service</div> <br />
              About Us Infomation Privacy Policy Terms & Conditions
            </div>

            <div className="footer_bottom_item">
              <div>My Account</div> <br />
              About Us Infomation Privacy Policy Terms & Conditions
            </div>



            <div className="footer_bottom_item">
              <div>Our Offers   </div> <br />
              About Us Infomation Privacy Policy Terms & Conditions
            </div>
          </div>







          <div className="footer_end">
              <div className="container">
                  <hr />
                  <div className="footer_logo">
                      <img src={require('./images/footer_it-park.png')} alt="" />
                  </div>
              </div>
          </div>
        </div>
      </footer>
    </>
  );
}

export default Footer;
