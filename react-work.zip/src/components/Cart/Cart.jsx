import "./Cart.css";
import { AiOutlineClose } from "react-icons/ai";
import { useState } from "react";

function Cart() {
  const [price, setPrice] = useState(60);
  const [qity, setQity] = useState(1);
  const [Modal, setModal] = useState(false);

  return (
    <>
      <div>
        <div className="container-cart">
          <section className="main">
            <div className="mainNav">
              <ul>
                <li>
                  <a>PRODUCT</a>
                </li>
              </ul>
              <ul className="dontknow">
                <li>
                  <a>PRICE</a>
                </li>
                <li>
                  <a>QITY</a>
                </li>
                <li>
                  <a>UNIT PRICE</a>
                </li>
              </ul>
            </div>
            <div className="productContainer">
              <div className="productInfo">
                <AiOutlineClose />
                <img src={require("./images/product.png")} alt="Product" />
                <h4>Nike Air Max Pro</h4>
              </div>
              <div className="saleProduct">
                <h4 className="cost">{price}$</h4>
                <div className="count">
                  <span
                    id="minus"
                    onClick={() => {
                      if (price <= 60) {
                        setPrice(60);
                        setQity(1);
                      } else {
                        setPrice(price - 60);
                        setQity(qity - 1);
                      }
                    }}
                  >
                    -
                  </span>
                  <span id="son">{qity}</span>
                  <span
                    id="plus"
                    onClick={() => {
                      if (price >= 580) {
                        setPrice(580);
                      } else {
                        setPrice(price + 60);
                        setQity(qity + 1);
                      }
                    }}
                  >
                    +
                  </span>
                </div>
                <h4 className="cost2">60$</h4>
              </div>
            </div>
          </section>
          <section className="sotib__Olish">
            <div>
              <div>
                <p>Subtotal</p>
                <p>Shipping free</p>
                <p>Cupon</p>
                <h3 className="total">TOTAL</h3>
              </div>
              <div>
                <p id="narx">0</p>
                <p id="free">0</p>
                <p id="cupon">no</p>
                <h4 id="total">{price}</h4>
              </div>
            </div>
            <button id="openModal" onClick={() => setModal(!Modal)}>Check Out</button>
          </section>
        </div>
        <div id="modal" className={Modal ? 'modal1show' : ''}>
          <span id="remove">
            <AiOutlineClose onClick={() => setModal(!Modal)} />
          </span>
          <h4>Make Payment</h4>
          <form>
            <input
              type="text"
              id="name"
              placeholder="Enter your name"
              required
            />
            <input
              type="text"
              name
              id="surname"
              placeholder="Last Name"
              required
            />
            <input
              type="email"
              name
              id="mail"
              placeholder="Email Adress"
              required
            />
            <input
              type="text"
              name
              id="delivery"
              placeholder="Enter Adress for delivery"
              required
            />
            <input
              type="text"
              name
              id="phone"
              placeholder="Phone number"
              required
            />
            <button type="submit" id="payment">
              Go To Payment
            </button>
          </form>
        </div>
        <div className="modalDone">
          <h4>Make Payment</h4>
          <h5 className="done">Done</h5>
          <button id="closeModal">Close</button>
        </div>
      </div>
    </>
  );
}

export default Cart;
