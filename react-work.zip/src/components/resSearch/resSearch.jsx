import Shop from "../Shop/Grid.jsx";
import './resSearch.css';

function resSearch() {
  return (
    <>
      <div className="responseSearch">
        <form action="#">
          <input type="text" placeholder="Search..."/>
          <button>Search</button>
        </form>
      </div>

      <Shop />
    </>
  );
}

export default resSearch;
