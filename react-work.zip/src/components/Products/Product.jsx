import { useState, useEffect } from "react";
import { useParams } from "react-router";
import { AiOutlineStar } from "react-icons/ai";
import { Link } from "react-router-dom";

import "./Products.css";

function Product() {
  const { id } = useParams();
  const [product, setProduct] = useState([]);
  const [loading, setLoading] = useState([]);

  useEffect(() => {
    const getProduct = async () => {
      setLoading(true);
      fetch("https://fakestoreapi.com/products/" + id)
        .then((res) => res.json())
        .then((result) => {
          setProduct(result);
        });
      setLoading(await false);
    };

    getProduct();
  }, []);
  return (
    <>
      <div className="seeProduct">
        <div className="seeProduct_left">
          <div className="seeProduct_left_main">
            <img src={product.image} alt="" />
          </div>

          {/* <div className="seeProduct_left_items">
            <div className="seeProduct_left_item">
              <img src={Porsche2} alt="Product 3d Model" />
            </div>

            <div className="seeProduct_left_item">
              <img src={Porsche3} alt="Product 3d Model" />
            </div>

            <div className="seeProduct_left_item">
              <img src={Porsche4} alt="Product 3d Model" />
            </div>

            <div className="seeProduct_left_item">
              <img src={Porsche5} alt="Product 3d Model" />
            </div>
          </div> */}
        </div>

        <div className="seeProduct_right">
          <div className="seeProduct_right_title">{product.title}</div>

          <div className="home-product_item_stars">
            <AiOutlineStar />
            <AiOutlineStar />
            <AiOutlineStar />
            <AiOutlineStar />
            <AiOutlineStar />
          </div>

          <hr />

          <div className="home-product_item_price">
            <span className="main-text">${product.price}</span>
          </div>

          <div className="other">
            <div className="other_item">
              <p>Availability:</p>
              <p>In stock</p>
            </div>

            <div className="other_item">
              <p>Category:</p>
              <p>{product.category}</p>
            </div>
          </div>


          <Link to={`/Cart`} className="grid_card_add">
            Download
          </Link>
          <br />
          <hr />
        </div>
      </div>
    </>
  );
}

export default Product;
