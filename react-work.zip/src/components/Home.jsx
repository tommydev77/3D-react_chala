import './HomePage/Styles/MainStyles.css'
import Main from './HomePage/Main/Main';
import FirstCards from "./HomePage/FirstCards/FirstCards";
import HomeCategories from "./HomePage/HomeCategories/HomeCategories";
import BestSeller from "./HomePage/BestSeller/BestSeller";
import HomeProduct from "./HomePage/HomeProduct/HomeProduct";
import RecomendedProduct from './HomePage/RecomendedProduct/RecomendedProduct';
import LoadMore from "./HomePage/LoadMoreLink/LoadMore";
import NoResponse from "./HomePage/noResponse/NoResponse";
function HomePage() {
  return (
    <>
      <Main />
      <FirstCards />
      <HomeCategories />
      <BestSeller />
      <HomeProduct />
      <RecomendedProduct />
      <HomeProduct />
      <LoadMore />
      <NoResponse />
    </>
  );
}

export default HomePage;