import * as Icon from "react-bootstrap-icons";

function NavTop() {
  return (
    <>
      <div className="navtop">
        <div className="container">
          <div className="navtop-left">
            <select name="lang" id="lang_id">
              <option value="en">EN</option>
              <option value="usd">RU</option>
            </select>

            <select name="valuta" id="valuta_id">
              <option value="usd">USD</option>
              <option value="rub">RUB</option>
            </select>
          </div>

          <div className="navtop-right">
            <ul>
              <li>
                <Icon.Person className="navtop_icon mx-2"/>
                My Profile
              </li>

              <li className="navtop_cart">
                <Icon.Cart className="navtop_cart navtop_icon"/>
              </li>

              <li>Items</li>

              <li>
                $0.00
                <Icon.Search className="mx-2 navtop_icon"/>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </>
  );
}

export default NavTop;
