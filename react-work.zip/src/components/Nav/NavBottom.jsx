import { Link } from "react-router-dom";

function NavBottom() {
  return (
    <>
      <header>
        <div className="container">
          <nav>
            <div className="nav-logo">E-Comm</div>

            <ul>
              <li>
                <Link to="/" className="nav-active">
                  HOME
                </Link>
              </li>

              <li>
                <Link to="/shop">
                  SHOP
                </Link>
              </li>

              <li>
                <Link to="/cart">
                  CART
                </Link>
              </li>
{/* 
              <li>
                <Link to="/">
                  BELT
                </Link>
              </li> */}

              <li>
                <Link to="/contact">
                  CONTACT
                </Link>
              </li>
            </ul>
          </nav>
        </div>
      </header>
    </>
  );
}

export default NavBottom;
