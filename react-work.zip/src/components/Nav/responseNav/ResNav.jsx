import "../NavStyles.css";
import { AiOutlineHome } from "react-icons/ai";
import { AiOutlineSearch } from "react-icons/ai";
import { AiOutlineShoppingCart } from "react-icons/ai";
import { MdOutlineLocalOffer } from "react-icons/md";
import { AiOutlineUser } from "react-icons/ai";
import { Link } from "react-router-dom";

function ResNav() {
  return (
    <>
      <div className="resNav">
        <ul className="resNav_items">
          <Link to="/">
            <li className="resNav_item active">
              <AiOutlineHome />
              Home
            </li>
          </Link>

          <Link to="/Search">
            <li className="resNav_item">
              <AiOutlineSearch />
              Search
            </li>
          </Link>
          <Link to="/Cart">
            <li className="resNav_item">
              <AiOutlineShoppingCart />
              Cart
            </li>
          </Link>

          <Link to="/Contact">
            <li className="resNav_item">
              <MdOutlineLocalOffer />
              Offer
            </li>
          </Link>

          <Link to="/">
            <li className="resNav_item">
              <AiOutlineUser />
              User
            </li>
          </Link>
        </ul>
      </div>
    </>
  );
}

export default ResNav;
