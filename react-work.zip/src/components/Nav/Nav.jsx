import NavTop from "./NavTop";
import NavBottom from "./NavBottom";
import ResNav from './responseNav/ResNav';
import './NavStyles.css';

function Nav() {
    return (
        <>
            <ResNav />
            <NavTop />
            <NavBottom />
        </>
    )
}

export default Nav;