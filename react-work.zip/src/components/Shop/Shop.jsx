import "./Shop.css";
import { BsGrid3X3GapFill } from "react-icons/bs";
import { GiHamburgerMenu } from "react-icons/gi";
import { Link } from "react-router-dom";
import ShopProduct from "./Products/ShopProduct.jsx";
import { useState, useEffect } from "react";
function Shop() {
  const [IsLoaded, setIsLoaded] = useState(false);
  const [Result, setResult] = useState("Salom");

  useEffect(() => {
    const getResult = async () => {
      setIsLoaded(false);
      fetch("https://fakestoreapi.com/products/")
        .then((res) => res.json())
        .then((result) => {
          setResult(result);
          setIsLoaded(true);
        });
      
    };
    getResult();
  }, []);
  
  // console.log(IsLoaded === true ? Result : 'ok');
  return (
    <>
      <div>
        <div className="backDrop" />
        <div className="container-shop">
          <section className="mainSection">
            <div className="leftMenu">
              <div className="hotDetals">
                <h4>Hot Details</h4>
                <hr />
                <ul>
                  <li>Adidas</li>
                  <li>Nike</li>
                  <li>Airmax</li>
                  <li>All Stars</li>
                </ul>
              </div>
              <div className="prices">
                <h4>PRICES</h4>
                <h5>Ranger</h5> <span>$13.99 - $25.99</span>
                <input type="range" name id />
              </div>
              <div className="colors">
                <h4>COLOR</h4>
                <div className="colorContainer">
                  <h6 className="colorValue" />
                  <h6 className="colorValue" />
                  <h6 className="colorValue" />
                  <h6 className="colorValue" />
                  <h6 className="colorValue" />
                </div>
              </div>
              <div className="brand">
                <h4>Brand</h4>
                <hr />
                <ul>
                  <li>Adidas</li>
                  <li>Nike</li>
                  <li>Siemens</li>
                </ul>
              </div>
            </div>
            <div className="main">
              <div className="shop_view_links">
                <Link to="/Grid">
                  <BsGrid3X3GapFill />
                </Link>
                <GiHamburgerMenu className="active shop_view_links_hamburger" />
              </div>
              <div className="banner">
                <div className="bannerInfo">
                  <h4>Adidas Men Running Sneakers</h4>
                  <p>Performance and design. Taken right to the edge</p>
                  <a href="#">Shop Now</a>
                </div>
                <div className="bannerImage">
                  <img
                    src={require("./images/product.png")}
                    alt="Shoes"
                    className="shoes"
                  />
                </div>
              </div>
              <div className="filterNav">
                <h4>** Items</h4>
                <h4>
                  <label htmlFor="choose">Sorted By:</label>
                  <select name id="choose">
                    <option value="size">Size</option>
                    <option value="name">Name</option>
                  </select>
                </h4>
              </div>

              {/* Product */}
              {IsLoaded
                ?
                Result.map((pos) => (
                    <ShopProduct
                      shopProduct={{
                        title: pos.title,
                        price: "$" + pos.price,
                        description: pos.description,
                        img: pos.image,
                        id: pos.id
                      }}
                    />
                  ))
                : ""
               }
              {/* END Product */}
            </div>
          </section>
        </div>
      </div>
    </>
  );
}

export default Shop;
