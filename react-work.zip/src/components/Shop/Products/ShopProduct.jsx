import { AiOutlineStar, AiOutlineHeart } from "react-icons/ai";
import { Link } from "react-router-dom";

function ShopProduct(props) {
  const post = props.shopProduct;

  return (
    <>
      <div className="profuctCard">
        <div className="productImage">
          <img src={post.img} className="img-fluid" alt="Shoes" />
        </div>
        <div className="productInfo">
          <div className="productName">{post.title}</div>
          <p className="productRate">
            <AiOutlineStar />
            <AiOutlineStar />
            <AiOutlineStar />
            <AiOutlineStar />
            <AiOutlineStar />
          </p>
          <p className="productCost">{post.price}</p>
          <p className="productDiscription">{post.description}</p>
          <p className="saleProduct">
            <Link to={"/products/" + post.id}>
              <button>See</button>
            </Link>
          </p>
        </div>
      </div>
    </>
  );
}

export default ShopProduct;
