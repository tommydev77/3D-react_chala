import { AiOutlineStar } from "react-icons/ai";
import { Link } from "react-router-dom";

function GridProduct(props) {
  const post = props.gridProduct;
  return (
    <>
      <div className="grid_card">
        <img src={post.img} alt="" />
        <div className="grid_card_title">{post.title}</div>

        <div className="grid_card_stars">
          <AiOutlineStar />
          <AiOutlineStar />
          <AiOutlineStar />
          <AiOutlineStar />
          <AiOutlineStar />
        </div>

        <div className="grid_card_prices">
          <div className="grid_card_prices_mainprice">{ post.price+'$'}</div>


        </div>
          <Link to={`/products/${post.id}`} className="grid_card_add">See</Link>

          <br />
      </div>
    </>
  );
}

export default GridProduct;
