import "./Shop.css";
import { BsGrid3X3GapFill } from "react-icons/bs";
import GridProduct from "./Products/GridProduct";
import { GiHamburgerMenu } from "react-icons/gi";
import { Link } from "react-router-dom";
import { Component } from "react";

class ShopProduct extends Component {
  compone;

  componentDidMount() {
    fetch("https://fakestoreapi.com/products")
      .then((res) => res.json())
      .then((result) => {
        this.setState({
          result: result,
          isLoaded: true  
        });

        console.log(this.state);

        this.ok();
      });
  }

  state = {isLoaded: false};

  render() {
    return (
      <>
        <div>
          <div className="backDrop" />
          <div className="container-shop">
            <section className="mainSection">
              <div className="leftMenu">
                <div className="hotDetals">
                  <h4>Hot Details</h4>
                  <hr />
                  <ul>
                    <li>Adidas</li>
                    <li>Nike</li>
                    <li>Airmax</li>
                    <li>All Stars</li>
                  </ul>
                </div>
                <div className="prices">
                  <h4>PRICES</h4>
                  <h5>Ranger</h5> <span>$13.99 - $25.99</span>
                  <input type="range" name id />
                </div>
                <div className="colors">
                  <h4>COLOR</h4>
                  <div className="colorContainer">
                    <h6 className="colorValue" />
                    <h6 className="colorValue" />
                    <h6 className="colorValue" />
                    <h6 className="colorValue" />
                    <h6 className="colorValue" />
                  </div>
                </div>
                <div className="brand">
                  <h4>Brand</h4>
                  <hr />
                  <ul>
                    <li>Adidas</li>
                    <li>Nike</li>
                    <li>Siemens</li>
                  </ul>
                </div>
              </div>
              <div className="main">
                <div className="shop_view_links">
                  <BsGrid3X3GapFill className="active" />
                  <Link to="/Shop">
                    <GiHamburgerMenu className="shop_view_links_hamburger" />
                  </Link>
                </div>
                <div className="banner">
                  <div className="bannerInfo">
                    <h4>Adidas Men Running Sneakers</h4>
                    <p>Performance and design. Taken right to the edge</p>
                    <a href="#">Shop Now</a>
                  </div>
                  <div className="bannerImage">
                    <img
                      src={require("./images/product.png")}
                      alt="Shoes"
                      className="shoes"
                    />
                  </div>
                </div>
                <div className="filterNav">
                  <h4>Items</h4>
                  <h4>
                    <label htmlFor="choose">Sorted By:</label>
                    <select name id="choose">
                      <option value="size">Size</option>
                      <option value="name">Name</option>
                    </select>
                  </h4>
                </div>

                <div className="grid_cards">
                  {/* Product */}
        

                  {!this.state.isLoaded
                    ? "Loading..."
                    : this.state.result.map((post) => (
                        <GridProduct
                          gridProduct={{
                            title: post.title,
                            description: post.description,
                            price: post.price,
                            img: post.image,
                            id: post.id
                          }}
                        />
                        
                      ))}

                  {/* END Product */}
                </div>
              </div>
            </section>
          </div>
        </div>
      </>
    );
  }
}

export default ShopProduct;
