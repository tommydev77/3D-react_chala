import './Contact.css'

function Contact() {
  return (
    <>
      <div className="contact">
        <div className="in-contact">
          <div className="contact-left">
            <h1>get in <br /> touch</h1>

            <p>contact@e-comm.ng</p>

            <p>+234 4556 6665 34</p>

            <p>20 Prince Hakerem Lekki <br /> Phase 1, Lagos.</p>
          </div>

          <div className="contact-right">
              <label htmlFor="fullname">Fullname</label>
              <input type="text" required placeholder='Fayozbek Erkinjonov'/>



              <label htmlFor="fullname">Email</label>
              <input type="email" required  placeholder='tommy@gmail.com'/>



              <label htmlFor="fullname">Message</label>
              <input type="text" required placeholder='Type your message'/>
          </div>
        </div>
      </div>
    </>
  );
}

export default Contact;
